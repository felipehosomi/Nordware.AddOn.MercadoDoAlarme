﻿namespace Nordware.AddOn.MercadoDoAlarme.Core
{
    public static class FormIDs
    {
        public const string CadastroItem = "150";
        public const string Cotacao = "149";
        public const string NotaFiscalSaida = "133";
        public const string PedidoVenda = "139";
    }
}