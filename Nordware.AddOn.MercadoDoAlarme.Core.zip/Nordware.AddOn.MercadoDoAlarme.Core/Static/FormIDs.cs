﻿namespace Nordware.AddOn.MercadoDoAlarme.Core.Static
{
    public class FormIDs
    {
        public const string CadastroItem = "150";
        public const string NotaFiscalSaida = "133";
        public const string PedidoVenda = "139";
        public const string Cotacao = "149";
        public const string RessarcimentoST = "FrmRessarcimentoST";
    }
}
